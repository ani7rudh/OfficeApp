package NIITApp;

import java.util.Scanner;

public class Address1 implements Methods
{
    String streetNm;
    String bldgname;
    String city;
    Scanner sc=new Scanner(System.in);
    
	@Override
	public void getdata() {
      System.out.println("enter Street name :");
      streetNm=sc.next();
      
      System.out.println("Enter Building name : ");
      bldgname=sc.next();
      System.out.println("Enter City :");
      city=sc.next();
	}
	@Override
	public void display() {
        System.out.println("Street no: "+streetNm);
        System.out.println("Building name"+bldgname);
        System.out.println("City name: "+city);
	}
    
    
}
