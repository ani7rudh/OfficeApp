package NIITApp;

import java.util.Scanner;

public class NIITMain {
     Scanner sc=new Scanner(System.in);
     Address1 a1=new Address1();
     public void menu()
     {
    	 System.out.println("***********MENU************");
    	 System.out.println("1. MRsupport");
    	 System.out.println("2. Faculty");
    	 System.out.println("3. Group Leader");
    	 System.out.println("4.Center Head");
    	 System.out.println("Enter Your choice Option");
    	 
    	 int m=sc.nextInt();
    	 switch(m)
    	 {
    	 case 1:
    		 MRSupport mr=new MRSupport();
    		 mr.getdata();
    		 a1.getdata();
    		 mr.display();
    		 a1.display();
    		 break;
    	 case 2:
    		 Faculty f=new Faculty();
    		 f.getdata();
    		 a1.getdata();
    		 f.display();
    		 a1.display();
    		 break;
    	 case 3:
    		 GroupLeader gl=new GroupLeader();
    		 gl.getdata();
    		 a1.getdata();
    		 gl.display();
    		 a1.display();
    		 break;
    	 case 4:
    		 CenterHead ch=new CenterHead();
    		 ch.getdata();
    		 a1.getdata();
    		 ch.display();
    		 a1.display();
    		 break;
    		 
         default:
        	 System.out.println("enter valid option");
        	 break;
        	 
    			 
    		 
    	 }
    	 yesno();
     }
     public void yesno()
     {
    	 System.out.println("Do you want to continue or not ?(y/n)");
    	 String s=sc.next();
    	 if (s.equalsIgnoreCase("y"))
    	 {
    		 menu();
    	 }
    	 else{
    		 System.exit(0);
    	 }
     }

	public static void main(String[] args) 
	{
       NIITMain nm=new NIITMain();
       nm.menu();
	}

}
