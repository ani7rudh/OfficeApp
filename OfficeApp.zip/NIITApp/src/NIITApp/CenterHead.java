package NIITApp;

import java.util.Scanner;

public class CenterHead extends EmployeeDetails implements Methods
{
    Scanner sc=new Scanner(System.in);
	@Override
	public void getdata() {

		System.out.println("enter first name of Center Head:");
		setFname(sc.next());
		System.out.println("enter last name of Center Head:");
		setLname(sc.next());
		System.out.println("enter gender of Center Head:");
		setGender(sc.next());
		System.out.println("enter age of Center Head:");
		setAge(sc.nextInt());
		System.out.println("enter email of Center Head:");
		setEmail(sc.next());
		System.out.println("enter Address of Center Head:");
		setAddress(sc.next());		
	}

	@Override
	public void display() {
		System.out.println("*********Center Head details***********");
		System.out.println("First name:"+getFname());
		System.out.println("Last name:"+getLname());
		System.out.println("gender:"+getGender());
		System.out.println("age:"+getAge());
		System.out.println("email:"+getEmail());
		System.out.println("Address:"+getAddress());		
	}

}
