
package NIITApp;

public interface Methods 
{
public void getdata();
public void display();

}
