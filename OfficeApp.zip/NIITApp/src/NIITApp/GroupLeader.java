package NIITApp;

import java.util.Scanner;

public class GroupLeader extends EmployeeDetails implements Methods
{
    String batchlaunch;
    int noofCR;
    int noofMR;
    Scanner sc=new Scanner(System.in);
    
	@Override
	public void getdata() {

		System.out.println("enter first name of Group Leader:");
		setFname(sc.next());
		System.out.println("enter last name of Group Leader:");
		setLname(sc.next());
		System.out.println("enter gender of Group Leader:");
		setGender(sc.next());
		System.out.println("enter age of Group Leader:");
		setAge(sc.nextInt());
		System.out.println("enter email of Group Leader:");
		setEmail(sc.next());
		System.out.println("enter Address of Group Leader:");
		setAddress(sc.next());		
		System.out.println("enter batch launch of Group Leader");
		batchlaunch=sc.next();
		System.out.println("enter no of CR of Group Leader");
		noofCR=sc.nextInt();
		System.out.println("enter no og=f MR of Group Leader");
		noofMR=sc.nextInt();
	}

	@Override
	public void display() {
		System.out.println("*********Group Leader details***********");
		System.out.println("First name:"+getFname());
		System.out.println("Last name:"+getLname());
		System.out.println("gender:"+getGender());
		System.out.println("age:"+getAge());
		System.out.println("email:"+getEmail());
		System.out.println("Address:"+getAddress());
		System.out.println("Batch Launch : "+batchlaunch);
		System.out.println("NO of CR"+noofCR);
		System.out.println("NO of MR"+noofMR);
	}

}
