package NIITApp;

import java.util.Scanner;

public class MRSupport extends EmployeeDetails implements Methods
{
	int noOfStudentSupported;
	String tasksAsssigned;
	Scanner sc=new Scanner(System.in);
	@Override
	public void getdata() {
		System.out.println("enter first name of MRSupport:");
		setFname(sc.next());
		System.out.println("enter last name of MRSupport:");
		setLname(sc.next());
		System.out.println("enter gender of MRSupport:");
		setGender(sc.next());
		System.out.println("enter age of MRSupport:");
		setAge(sc.nextInt());
		System.out.println("enter email of MRSupport:");
		setEmail(sc.next());
		System.out.println("enter Address of MRSupport:");
		setAddress(sc.next());
		System.out.println("enter no of students supported of MRSupport:");
		noOfStudentSupported=sc.nextInt();
		System.out.println("enter task assigned of MRSupport:");
		tasksAsssigned=sc.next();

	}
	@Override
	public void display()
	
	{
		System.out.println("*********MRSupport details***********");
		System.out.println("First name:"+getFname());
		System.out.println("Last name:"+getLname());
		System.out.println("gender:"+getGender());
		System.out.println("age:"+getAge());
		System.out.println("email:"+getEmail());
		System.out.println("Address:"+getAddress());
		System.out.println("no of students supported:"+noOfStudentSupported);
        System.out.println("task Assigned:"+tasksAsssigned);		
		
	}

}
