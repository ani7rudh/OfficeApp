package NIITApp;

import java.util.Scanner;

public class Faculty extends EmployeeDetails implements Methods
{
    String batchtiming;
    String coursename;
    int noofstudents;
    Scanner sc=new Scanner(System.in);
	@Override
	public void getdata() {

		System.out.println("enter first name of Faculty:");
		setFname(sc.next());
		System.out.println("enter last name of Faculty:");
		setLname(sc.next());
		System.out.println("enter gender of Faculty:");
		setGender(sc.next());
		System.out.println("enter age of Faculty:");
		setAge(sc.nextInt());
		System.out.println("enter email of Faculty:");
		setEmail(sc.next());
		System.out.println("enter Address of Faculty:");
		setAddress(sc.next());		
		System.out.println("enter batch timing of faculty: ");
		batchtiming=sc.next();
		System.out.println("enter course name of faculty");
		coursename=sc.next();
		System.out.println("enter no of students of faculty");
		noofstudents=sc.nextInt();
		
	}  
	@Override
	public void display() {
		System.out.println("*********Faculty details***********");
		System.out.println("First name:"+getFname());
		System.out.println("Last name:"+getLname());
		System.out.println("gender:"+getGender());
		System.out.println("age:"+getAge());
		System.out.println("email:"+getEmail());
		System.out.println("Address:"+getAddress());
		System.out.println("Batch Timing : "+batchtiming);
		System.out.println("Course name : "+coursename);
		System.out.println("No Of Students : "+noofstudents);
	}
    
}
